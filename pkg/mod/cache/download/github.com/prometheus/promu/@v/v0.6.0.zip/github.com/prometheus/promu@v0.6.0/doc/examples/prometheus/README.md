Prometheus example

Run `promu build` to build prometheus
