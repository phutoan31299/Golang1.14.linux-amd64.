Crossbuild example

Run `promu crossbuild` to crossbuild for linux-386 and linux-amd64 platforms.
Output will be in the `.build` directory.

Run `promu crossbuild tarballs` to build platform tarballs.
Output will be in the `.tarballs` directory.
