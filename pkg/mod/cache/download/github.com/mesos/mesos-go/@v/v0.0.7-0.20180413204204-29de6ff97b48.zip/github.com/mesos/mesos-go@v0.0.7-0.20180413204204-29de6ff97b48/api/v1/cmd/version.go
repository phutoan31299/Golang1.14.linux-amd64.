package cmd

// DockerImageTag should be populated by the build system
var DockerImageTag = ""
