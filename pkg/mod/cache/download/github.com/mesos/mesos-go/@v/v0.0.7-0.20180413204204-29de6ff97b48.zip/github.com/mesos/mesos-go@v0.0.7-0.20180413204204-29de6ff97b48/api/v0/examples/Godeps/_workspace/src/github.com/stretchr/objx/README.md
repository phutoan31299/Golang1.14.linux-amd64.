# objx

  * Jump into the [API Documentation](http://godoc.org/github.com/stretchr/objx)
