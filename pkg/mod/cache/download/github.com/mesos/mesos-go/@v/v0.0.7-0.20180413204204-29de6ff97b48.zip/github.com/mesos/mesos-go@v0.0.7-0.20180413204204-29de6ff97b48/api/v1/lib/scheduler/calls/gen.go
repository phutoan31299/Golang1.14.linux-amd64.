package calls

//go:generate go run ../../extras/gen/callers.go ../../extras/gen/gen.go -import github.com/mesos/mesos-go/api/v1/lib/scheduler -type C:*scheduler.Call
