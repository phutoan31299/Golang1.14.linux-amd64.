// mwatch is an example utility that observes events happening on a mesos master.

package main
