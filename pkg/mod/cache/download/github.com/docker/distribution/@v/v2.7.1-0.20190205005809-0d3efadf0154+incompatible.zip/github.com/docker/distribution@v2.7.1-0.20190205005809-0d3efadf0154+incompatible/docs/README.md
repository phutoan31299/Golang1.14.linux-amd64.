# The docs have been moved!

The documentation for Registry has been merged into
[the general documentation repo](https://github.com/docker/docker.github.io).
Commit history has been preserved.

The docs for Registry are now here:
https://github.com/docker/docker.github.io/tree/master/registry

> Note: The definitive [./spec directory](spec/) directory and
[configuration.md](configuration.md) file will be maintained in this repository
and be refreshed periodically in
[the general documentation repo](https://github.com/docker/docker.github.io).

As always, the docs in the general repo remain open-source and we appreciate
your feedback and pull requests!
